package com.example.recyclerview_ricaborda;

public class PlanetModel {
    String planetName;
    int planetImage;


    public PlanetModel(String planetName, int planetImage) {
        this.planetName = planetName;
        this.planetImage = planetImage;
    }

    public String getPlanetName() {
        return planetName;
    }

    public int getPlanetImage() {
        return planetImage;
    }
}

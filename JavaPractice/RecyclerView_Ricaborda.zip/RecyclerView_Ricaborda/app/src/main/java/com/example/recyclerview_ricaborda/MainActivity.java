package com.example.recyclerview_ricaborda;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    ArrayList<PlanetModel> planets = new ArrayList<>();

    int [] planetImage = { R.drawable.mercury, R.drawable.jupiter, R.drawable.mars,
            R.drawable.neptune, R.drawable.saturn, R.drawable.uranus, R.drawable.venus, R.drawable.earth

    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(this, planets);
        recyclerView.setAdapter(adapter);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        modelPlanets();
    }

    private void modelPlanets(){
        String[] planetName = getResources().getStringArray(R.array.planet_name);

        for (int i = 0; i < planetName.length; i++) {
            planets.add(new PlanetModel(planetName[i], planetImage[i]));

        }
    }
}
package com.example.recyclerview_ricaborda;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder> {

    Context context;
    ArrayList<PlanetModel> planets;

    public RecyclerViewAdapter(Context context, ArrayList<PlanetModel> planets) {
        this.context = context;
        this.planets = planets;
    }

    @NonNull
    @Override
    public RecyclerViewAdapter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.recyclearview_row, parent, false);

        return new RecyclerViewAdapter.MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerViewAdapter.MyViewHolder holder, int position) {
        holder.txt1.setText(planets.get(position).getPlanetName());
        holder.img1.setImageResource(planets.get(position).getPlanetImage());
    }

    @Override
    public int getItemCount() {
        return planets.size();
    }


    public static class MyViewHolder extends RecyclerView.ViewHolder{

        TextView txt1;
        ImageView img1;
        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            txt1 =itemView.findViewById(R.id.txt1);
            img1 = itemView.findViewById(R.id.img1);
        }
    }
}
